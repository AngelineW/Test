from tkinter import *
from datetime import datetime
from tkinter import messagebox
import uuid
import mysql.connector

from mysql.connector import errors

from tkinter import ttk

class Employees:
    def __init__(self,root, staff_id):
        self.root = root
        self.root.title("staff")
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        self.root.geometry("{}x{}+0+0".format(screen_width, screen_height))

        conn = mysql.connector.connect(
                    host = "localhost",
                    user = "root",
                    password = "password#123",
                    database = "hospital_db"
        )
        c = conn.cursor()

        l1 = StringVar()
        l2 = StringVar()
        l3 = StringVar()
        l4 = StringVar()
        l5 = StringVar()
        l6 = StringVar()
        l7 = StringVar()
        l8 = StringVar()
        l9 = StringVar()

        def clear():
            l1.set('')
            l2.set('')
            l3.set('')
            l4.set('')
            l5.set('')
            l6.set('')
            l7.set('')
            l8.set('')
            l9.set('')
        
        def getemployeerow(event):
            clear()
            global selected_record_id
            selected = tv.focus()
            details = tv.item(selected, 'values')
            l1.set(details[1])
            l2.set(details[2])
            l3.set(details[3])
            l4.set(details[4])
            l5.set(details[5])
            l6.set(details[6])
            l7.set(details[7])

            staff_id = details[1]

            query = "SELECT id FROM employee_detail WHERE staff_id LIKE '%" + staff_id +"%' GROUP BY id ORDER BY id"
            c.execute(query)
            results = c.fetchall()
            selected_record_id = results[0][0]
            print(selected_record_id)
        
        def read_today():
            read()

        def create():
            try:
                selected_id = selected_record_id
                if selected_id == '':
                    pass
                else:
                    messagebox.showerror('ERROR','Select Update or Delete.\n'
                    'OR\n'
                    'Press reset to continue adding records')
                    return
            except NameError:
                pass
            if len(l1.get()) == 0 or len(l2.get()) == 0 or len(l3.get()) == 0 or len(l4.get()) == 0 or len(l5.get()) == 0 or len(l6.get()) == 0: 
                messagebox.showerror('ERROR', " Enter all values")
                return
            
            if l1.get().isspace() or l2.get().isspace() or l3.get().isspace() or l4.get().isspace() or l5.get().isspace() or l6.get().isspace():
                messagebox.showerror('ERROR', "Enter valid values")
                return
            else:
                pass
                       
            id=  str(uuid.uuid4())
            tdate = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            staff_id = l1.get().upper()
            title = l2.get().upper()
            first_name = l3.get().upper()
            last_name = l4.get().upper()
            other_name = l5.get().upper()
            user_type = l6.get().upper()
            username = l7.get()
            password = l8.get()


            query = "INSERT INTO employee_detail(id, date, staff_id, title, first_name, last_name, other_name, user_type, username, password) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)" 
            val = ( id, tdate, staff_id, title, first_name, last_name, other_name, user_type, username, password)
            
            try:
                c.execute(query, val)
                conn.commit()

                messagebox.showinfo('Ok','{} saved as a user'.format(first_name))
                clear()
                read_today()

            except errors.IntegrityError:
                messagebox.showerror('ERROR', "Record Already Exists")
                clear()
                return
        
        def read():
            tv.delete(*tv.get_children())
            query = "SELECT date, staff_id, title, first_name, last_name, other_name, user_type, username   FROM employee_detail ORDER BY date desc"
            c.execute(query)

            users = c.fetchall()
            for user in users:
                tv.insert('', 'end', values=user)

        def update():
            try:
                update_id = selected_record_id
                if update_id == '':
                    messagebox.showerror('Error','Select Record To Be Updated')
                    return
                else:
                    pass
            except NameError:
                messagebox.showerror('Error','Select Record To Be Updated')
                return
            
            if len(l1.get()) >= 1 and len(l2.get()) >= 1 and len(l3.get()) >= 1 and len(l4.get()) >= 1 and len(l5.get()) >= 1 and len(l6.get()) >= 1:
                pass
            else:
                messagebox.showerror('ERROR', "All fields are required")
                return
            
            if l1.get().isspace() or l2.get().isspace() or l3.get().isspace() or l4.get().isspace() or l5.get().isspace() or l6.get().isspace():
                messagebox.showerror('ERROR', "Select Record to be Updated")
                return
            else:
                pass

    

            staff_id = l1.get()
            title = l2.get()
            first_name = l3.get()
            last_name = l4.get()
            other_name = l5.get()
            user_type = l6.get()
            username = l7.get()
            password = l8.get()
            
            query = "UPDATE employee_detail SET staff_id = '" + staff_id +"', title = '" + title +"', first_name = '" + first_name +"', last_name = '" + last_name +"', other_name = '" + other_name +"', user_type = '" + user_type +"', username = '" + username +"', password = '" + password +"' WHERE id LIKE '" + update_id +"'"

            print(query)

            c.execute(query)
            conn.commit()

            messagebox.showinfo('OK','{} Updated'.format(staff_id))
            clear()
            read()

        def delete():
            try:
                delete_id = selected_record_id
                if delete_id == '':
                    messagebox.showerror('Error','Select Record To Be Updated')
                    return
                else:
                    pass
            except NameError:
                messagebox.showerror('Error','Select Record To Be Deleted')
                return

            if len(l1.get()) >= 1 and len(l2.get()) >= 1 and len(l3.get()) >= 1 and len(l4.get()) >= 1 and len(l5.get()) >= 1 and len(l6.get()) >= 1:
                pass
            else:
                messagebox.showerror('ERROR', "The form requires all fields to be deleted,\n"
                "Select Record To Be Updated")
                return
            if l1.get().isspace() or l2.get().isspace() or l3.get().isspace() or l4.get().isspace() or l5.get().isspace() or l6.get().isspace():
                messagebox.showerror('ERROR', "Select Record to be Deleted")
                return
            else:
                pass

            if messagebox.askyesno("DELETE!","Are you sure you want to delete {} from record".format(l3.get())):    
                query = "DELETE FROM employee_detail WHERE id LIKE '" + delete_id +"'"
                c.execute(query)
                conn.commit()
                staff_id = l1.get()
                messagebox.showinfo('Ok', "Successfully deleted {}".format(staff_id))
                clear()
                read()
            else:
                return

        def search():
            staff_id = l9.get().upper()

            if l9.get() == '':
                messagebox.showerror('ERROR', "Enter Staff Id")
                return

            elif l9.get().isspace():
                messagebox.showerror('ERROR', "Enter a valid input")
                return
         
            else:
                pass
             
            global selected_record_id
            query = "SELECT id, date, staff_id, title, first_name, last_name, other_name, user_type, username, password FROM employee_detail WHERE staff_id LIKE '" + staff_id +"'"
            c.execute(query)

            details = c.fetchall()

            if details == []:
                messagebox.showerror('ERROR','Enter a valid Staff ID')
                return

            entries = []
            for detail in details:
                for value in detail:
                    entries.append(value)
            print(entries)

            selected_record_id = entries[0]
            l1.set(entries[2])
            l2.set(entries[3])
            l3.set(entries[4])
            l4.set(entries[5])
            l5.set(entries[6])
            l6.set(entries[7])
            l7.set(entries[8])
            l8.set(entries[9])
                    

        def reset():
            global selected_record_id
            selected_record_id = ''
            clear()

        def back():
            frame.destroy()
            import admin
            admin.Admin(root, staff_id)


        frame=Frame(root)
        frame.pack(fill=BOTH, expand=True, padx=(0, 0))

        frame2 = Frame(frame, )
        frame2.place(x=1, y=490, relwidth=1, relheight=0.42)

        Label(frame, text="STAFF DETAILS", font=("times new roman", 40, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=350, y=5)
               
        Label(frame, text="Staff id:", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=5, y=100)
        Entry(frame, font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, textvariable=l1).place(x=200, y=100)
        
        Label(frame, text="Title:", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, ).place(x=5, y=140)
        Entry(frame, text="Admin Form", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, textvariable=l2).place(x=200, y=140)

        Label(frame, text="First Name:", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, ).place(x=5, y=180)
        Entry(frame, text="Admin Form", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, textvariable=l3).place(x=200, y=180)
        
        Label(frame, text="Last Name:", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=5, y=220)
        Entry(frame, text="Admin Form", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, textvariable=l4).place(x=200, y=220)
        
        Label(frame, text="Other Name:", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=5, y=260)
        Entry(frame, text="Admin Form", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, textvariable=l5).place(x=200, y=260)

        Label(frame, text="User Type:", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=5, y=300)
        Entry(frame, font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, textvariable=l6).place(x=200, y=300)

        Label(frame, text="Username:", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE,).place(x=5, y=340)
        Entry(frame, font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, textvariable=l7).place(x=200, y=340)

        Label(frame, text="Password:", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=5, y=380)
        Entry(frame,  font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, textvariable=l8).place(x=200, y=380)

        
        Entry(frame, font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", width = 15, textvariable = l9).place(x=950, y=100)
                    
        Button(frame, text="Search", command = search, font=("", 10, "bold",), bg="#068481", fg="#b0c4de", width=10).place(
            x= 1180, y=100,)
        
        Button(frame, text="Add", command=create, font=("", 10, "bold",), bg="#068481", fg="#b0c4de", width=15).place(
            x=450, y=420)
        Button(frame, text="Display", command=read, font=("", 10, "bold",), bg="#506987", fg="#c1cdc1",
                    width=15).place(x=625, y=420)
        Button(frame, text="Update", command=update, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=800, y=420)
        Button(frame, text="Delete", command=delete, font=("", 10, "bold",), bg="#8b4c39", fg="#f6c9cc",
                    width=15).place(x=970, y=420)
        Button(frame, text="Reset", command=reset, font=("", 10, "bold",), bg="#003f87", fg="White",
                    width=15).place(x=1150, y=420)

        Button(frame, text="Back", command=back, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=50, y=50)

        # ===============================================Create table==================================================
        tv = ttk.Treeview(frame2, columns=(1, 2, 3, 4, 5, 6, 7, 8, 9), show="headings", height="5")
        xscrollbar = ttk.Scrollbar(frame2, orient="horizontal", command=tv.xview)
        xscrollbar.pack(side=BOTTOM, fill="x")
        yscrollbar = ttk.Scrollbar(frame2, orient=VERTICAL, command=tv.yview)
        yscrollbar.pack(side=RIGHT, fill=Y)

        tv.configure(xscrollcommand=xscrollbar.set)
        tv.configure(yscrollcommand=yscrollbar.set)

        tv.column(1, width=55)
        tv.column(2, width=100)
        tv.column(3, width=50)
        tv.column(4, width=100)
        tv.column(5, width=100)
        tv.column(6, width=100)
        tv.column(7, width=100)
        tv.column(8, width=100)
        tv.column(9, width=100)

        tv.heading(1, text="Date")
        tv.heading(2, text="Staff ID")
        tv.heading(3, text="Title")
        tv.heading(4, text="First Name")
        tv.heading(5, text="Last Name")
        tv.heading(6, text="Other Name")
        tv.heading(7, text="Usertype")
        tv.heading(8, text="Username")
        tv.heading(9, text="Password")

        tv.bind('<Double-1>', getemployeerow)
        tv.pack(fill=BOTH, expand=1)


# root= Tk()
# Employees(root, 'AD001')
# root.mainloop()