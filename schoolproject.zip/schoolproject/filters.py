from tkinter import *
from tkinter import ttk
from tkcalendar import *
import mysql.connector
from tkinter import messagebox

import xlsxwriter

from datetime import datetime

class Reports:
    def __init__(self, root, staff_id):
        self.root=root
        self.root.title("Reports")
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        self.root.geometry("{}x{}+0+0".format(screen_width, screen_height))
        
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="password#123",
			database = "hospital_db"
        )
        c = conn.cursor()

        t1 = StringVar()
        t2 = StringVar()
        t3 = StringVar()
        t4 = StringVar()
        t5 = StringVar()
        t6 = StringVar()
        t7 = StringVar()
        t8 = StringVar()
        t9 = StringVar()
        t10 = StringVar()

        def clear_filter():
            t1.set('')
            t2.set('')
            t3.set('')
            t4.set('')
            t5.set('')


        def read(entries):
            tv.delete(*tv.get_children())
            for entry in entries:
                tv.insert('', 'end', values=entry)
               
        def filter_by_department(department):
            c = conn.cursor()
            print("filtering by department")

            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status  FROM queue WHERE department LIKE '" + department + "' ORDER BY date desc"
            c.execute(query1)
            entries = c.fetchall()
            if entries == []:
                messagebox.showinfo('OK!','There are no entries under {}'.format(department))
            else:
                print(entries)
                read(entries)
                print(c.fetchall())
        
        def filter_by_role(role):
            c = conn.cursor()
            print("filtering by role")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue WHERE role LIKE '{}' ORDER BY date desc".format(role)
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
            print(entries)

        def filter_by_specialist(specialist):
            c = conn.cursor()
            print("filtering by specialist")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue WHERE specialist_name LIKE '{}' ORDER BY date desc".format(specialist)
            c.execute(query1)
            entries = c.fetchall()
            read(entries)

        def filter_by_start_date_and_end_date(start_date,end_date):
            print("filtering by start and end date")
            c = conn.cursor()
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue WHERE date between '{}' AND '{}'".format(start_date, end_date)
            print(query1)
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
            print(entries)

        def filter_by_department_and_role(department,role):
            c = conn.cursor()
            print("filtering by department and role")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue  WHERE department LIKE  '{}' AND role LIKE '{}' ORDER BY date desc".format(department, role)
            print(query1)
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
            print(entries)
            
        def filter_by_department_and_specialist(department,specialist):
            c = conn.cursor()
            print("filtering by department and specialist")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue  WHERE department LIKE  '{}' AND specialist_name LIKE '{}' ORDER BY date desc".format(department, specialist)
            print(query1)
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
           
        def filter_by_department_role_and_specialist(department,role,specialist):
            c = conn.cursor()
            print("filtering by department, role and specialist")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue  WHERE department LIKE  '{}' AND role LIKE '{}' AND specialist_name LIKE '{}' ORDER BY date desc".format(department, role, specialist)
            print(query1)
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
         
        def filter_by_role_specialist(role,specialist):
            c = conn.cursor()
            print("filtering by role and specialist")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue  WHERE  role LIKE '{}' AND specialist_name LIKE '{}' ORDER BY date desc".format(role, specialist)
            print(query1)
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
         
        def filter_by_department_and_start_date_and_end_date(department,start_date,end_date):
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue WHERE department LIKE '{}' AND date between '{}' AND '{}'".format(department, start_date, end_date) 
            print("filtering by department and start date")
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
            print(entries)
                
        def filter_by_role_start_date_and_end_date(role,start_date,end_date):
            c = conn.cursor()
            print("filtering by role, start date and end date")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue WHERE role LIKE '{}' AND date between '{}' AND '{}'".format(role, start_date, end_date) 
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
            print(entries)
        
        def filter_by_specialist_and_start_date_and_end_date(specialist,start_date,end_date):
            c = conn.cursor()
            print("filtering by specialist, start date and end date")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue WHERE specialist_name LIKE '{}' AND date between '{}' AND '{}'".format(specialist, start_date, end_date) 
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
        
        def filter_by_department_role_start_date_and_end_date(department,role,start_date,end_date):
            c = conn.cursor()
            print("filtering by department, role, start date and end date")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue WHERE department LIKE '{}' AND role LIKE '{}' AND date between '{}' AND '{}'".format(department, role, start_date, end_date) 
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
            print(entries)

        def filter_by_department_specialist_start_date_and_end_date(department,specialist,start_date,end_date):
            c = conn.cursor()
            print("filtering by department, specialist, start date and end date")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue WHERE department LIKE '{}' AND specialist_name LIKE '{}' AND date between '{}' AND '{}'".format(department, specialist, start_date, end_date) 
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
            print(entries)

        def filter_by_role_specilaist_start_date_and_end_date(role,specialist,start_date,end_date):
            c = conn.cursor()
            print("filtering by role, specialist, start date and end date")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue WHERE role LIKE '{}' AND specialist_name LIKE '{}' AND date between '{}' AND '{}'".format(role, specialist, start_date, end_date) 
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
            print(entries)
        
        def filter_by_department_role_specialist_start_date_and_end_date(department,role,specialist,start_date,end_date):
            c = conn.cursor()
            print("filtering by department, role, specialist, start date and end date")
            query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue WHERE role LIKE '{}' AND role LIKE '{}' AND specialist_name LIKE '{}' AND date between '{}' AND '{}'".format(department, role, specialist, start_date, end_date) 
            c.execute(query1)
            entries = c.fetchall()
            read(entries)
            print(entries)
        
        
      
        def filter():
            tv.delete(*tv.get_children())
            if t1.get() != "" and t2.get() == "" and t3.get() == "" and t4.get() == "" and t5.get() == "":
                print(t1.get())
                department = t1.get()
                filter_by_department(department)
                clear_filter()
            

            if t1.get() == "" and t2.get() != "" and t3.get() == "" and t4.get() == "" and t5.get() == "":
                role = t2.get()
                print(role)
                filter_by_role(role)
                clear_filter()
            

            elif t1.get() == "" and t2.get() == "" and t3.get() != "" and t4.get() == "" and t5.get() == "":
                specialist = t3.get()
                filter_by_specialist(specialist)
                clear_filter()


            elif t1.get() == "" and t2.get() != "" and t3.get() != "" and t4.get() == "" and t5.get() == "":
                role = t2.get()
                specialist = t3.get()
                filter_by_role_specialist(role,specialist)
                clear_filter()



            elif t1.get() == "" and t2.get() == "" and t3.get() == "" and t4.get() != "" and t5.get() != "":
                start_date = t4.get()
                end_date = t5.get()
                filter_by_start_date_and_end_date(start_date,end_date)
                clear_filter()

            
            elif t1.get() != "" and t2.get() != "" and t3.get() != "" and t4.get() == "" and t5.get() == "":
                department = t1.get()
                role = t2.get()
                specialist = t3.get()

                filter_by_department_role_and_specialist(department,role,specialist)
                clear_filter()



            elif t1.get() != "" and t2.get() != "" and t3.get() == "" and t4.get() == "" and t5.get() == "":
                department = t1.get()
                role = t2.get()

                filter_by_department_and_role(department,role)
                clear_filter()


            elif t1.get() != "" and t2.get() == "" and t3.get() != "" and t4.get() == "" and t5.get() == "":
                department = t1.get()
                specialist = t3.get()
                filter_by_department_and_specialist(department,specialist)
                clear_filter()


            elif t1.get() != "" and t2.get() == "" and t3.get() == "" and t4.get() != "" and t5.get() != "":
                department = t1.get()
                start_date = t4.get()
                end_date = t5.get()

                filter_by_department_and_start_date_and_end_date(department,start_date,end_date)
                clear_filter()


            elif t1.get() == "" and t2.get() != "" and t3.get() == "" and t4.get() != "" and t5.get() != "":
                role = t2.get()
                start_date = t4.get()
                end_date = t5.get()
                filter_by_role_start_date_and_end_date(role,start_date,end_date)
                clear_filter()

            
            elif t1.get() == "" and t2.get() == "" and t3.get() != "" and t4.get() != "" and t5.get() != "":
                specialist = t3.get()
                start_date = t4.get()
                end_date = t5.get()

                filter_by_specialist_and_start_date_and_end_date(specialist,start_date,end_date)
                clear_filter()


            elif t1.get() != "" and t2.get() != "" and t3.get() == "" and t4.get() != "" and t5.get() != "":
                department = t1.get()
                role = t2.get()
                start_date = t4.get()
                end_date = t5.get()
                filter_by_department_role_start_date_and_end_date(department,role,start_date,end_date)
                clear_filter()


            elif t1.get() != "" and t2.get() == "" and t3.get() != "" and t4.get() != "" and t5.get() != "":
                department = t1.get()
                specialist = t3.get()
                start_date = t4.get()
                end_date = t5.get()
                filter_by_department_specialist_start_date_and_end_date(department,specialist, start_date,end_date)
                clear_filter()


            elif t1.get() == "" and t2.get() != "" and t3.get() != "" and t4.get() != "" and t5.get() != "":
                role = t2.get()
                specialist = t3.get()
                start_date = t4.get()
                end_date = t5.get()
                filter_by_role_specilaist_start_date_and_end_date(role,specialist,start_date,end_date)
                clear_filter()


            elif t1.get() != "" and t2.get() != "" and t3.get() != "" and t4.get() != "" and t5.get() != "":
                department = t1.get()
                role = t2.get()
                specialist = t3.get()
                start_date = t4.get()
                end_date = t5.get()
                filter_by_department_role_specialist_start_date_and_end_date(department,role,specialist,start_date,end_date)
                clear_filter()

            
        def get_department():
            query1 = "SELECT name FROM department GROUP BY name ORDER BY name asc"
            c.execute(query1)
            departments = []
            rows = c.fetchall()

                                    
            for row in rows:
                departments.append(row[0])

            return departments

        def get_role():
            query1 = "SELECT name FROM role GROUP BY name ORDER BY name asc"
            c.execute(query1)
            roles = []
            rows = c.fetchall()

            for row in rows:
                roles.append(row[0])
            
            return roles

        def get_specialist():
            query1 = "SELECT title, first_name, last_name FROM employee_detail GROUP BY staff_id ORDER BY first_name desc"
            c.execute(query1)
            specialists = []
            details = c.fetchall()

            for row in details:
                name = row[0] + ' ' + row[1] + ' ' + row[2]
                specialists.append(name)
            print("specialists", specialists)
            return specialists

        def display_role():
            if t1.get() != "":
                department = t1.get()
                query1 = "SELECT name FROM role WHERE department LIKE '" + department + "' GROUP BY name ORDER BY name desc"
                c.execute(query1)
                roles = []
                rows = c.fetchall()

                for row in rows:
                    roles.append(row[0])
                
                print(roles)
                txtrole['values'] = roles

        def display_specialist():
            if t2.get() != "":
                role = t2.get()
                query1 = "SELECT title, first_name, last_name FROM employee_detail WHERE user_type LIKE '" + role + "' GROUP BY staff_id ORDER BY first_name desc"
                c.execute(query1)
                specialists = []
                rows = c.fetchall()

                print(rows)

                for row in rows:
                    details = row[0] + ' ' + row[1] + ' ' + row[2]

                    specialists.append(details)
                print("Specialists",specialists)
                txtspecialist['values'] = specialists

            else:
                messagebox.showerror('ERROR!','Select the Specialist Role')

        def clear_search():
            txtsearch.delete(0, END)

        
        def search():
            c = conn.cursor()
            if t6.get() == "" or t6.get().isspace():
                messagebox.showerror('ERROR', "Enter department, role, specialist or staff Id")

            else:
                search_entry = t6.get()
                query1 = "SELECT date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status FROM queue WHERE department LIKE '{}' OR role LIKE '{}' OR specialist_name LIKE '{}' OR staff_id LIKE '{}' OR patient_card_no LIKE '{}'".format(search_entry, search_entry, search_entry, search_entry, search_entry)
                print(query1)
                c.execute(query1)
                rows = c.fetchall()
                print("Result", rows)
                if rows == []:
                    messagebox.showerror('ERROR',"There is no search entry in queue")

                else:
                    tv.delete(*tv.get_children())
                    for row in rows:
                        tv.insert('', 'end', values=row)

                clear_search()

        def print_report():
            details = []
            column_headers = ['Date','Department','Role',  'Staff ID', 'Specialist Name', 'Patient Card No', 'Patient Name', 'Current Queue', 'In Queue']
            details.append(column_headers)
            if tv.get_children() == ():
                messagebox.showerror('ERROR', "There are no filtered values")
                return
            
            else:
                print(tv.get_children())
                for row in tv.get_children():
                    entries = tv.item(row)['values']
                    details.append(entries)
                
                print("All Rows",details)
                current =datetime.now().strftime("%Y-%m-%d %H%M%S")
                with xlsxwriter.Workbook('Filtered Queue Report {}.xlsx'.format(current)) as workbook:  #generate file Report.xlsx
                    worksheet = workbook.add_worksheet()
                    for row_num, data in enumerate(details):
                        worksheet.write_row(row_num, 0, data)
            
            messagebox.showinfo('SUCCESS','The report was successfuly generated')

        def back():
            frame.destroy()
            import admin
            admin.Admin(root, staff_id)


        frame = Frame(root)
        frame.pack(fill=BOTH, expand=True, padx=(0, 0))

        frame2 = Frame(frame, )
        frame2.place(x=1, y=200, relwidth=1, relheight=0.72)
        
        formlbl = Label(frame, text="Queue Reports", font=("times new roman", 40, "bold", "italic"),
                        bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=500, y=5)
        lbldpt = Label(frame, text="Department:", compound=LEFT,bg="#a9acb6",
                        font=("times new roman", 20, "bold")).place(x=0, y=80)
        txtdpt = ttk.Combobox(frame, width=18, font=(" ", 15,"bold",),textvariable=t1)
        txtdpt.place(x=165, y=85)
        txtdpt['values'] = get_department()

         
        lblrole = Label(frame, text="Role:", compound=LEFT,bg="#a9acb6",
                        font=("times new roman", 20, "bold",), ).place(x=480, y=80)
        txtrole = ttk.Combobox(frame, width=18, font=(" ", 15,"bold",),textvariable=t2)
        txtrole.place(x=560, y=85)
        txtrole['values'] = get_role()

        lblspecialist = Label(frame, text="Specialist:", compound=LEFT,bg="#a9acb6",
                        font=("times new roman", 20, "bold",), ).place(x=880, y=80)
        txtspecialist = ttk.Combobox(frame, width=18, font=(" ", 15,"bold",),textvariable=t3)
        txtspecialist.place(x=1020, y=85)
        txtspecialist['values'] = get_specialist()
        
        lblstart_date = Label(frame, text="Start Date:", compound=LEFT,bg="#a9acb6",
                        font=("times new roman", 15, "bold",), ).place(x=400, y=158)
        lblend_date = Label(frame, text="End date:", compound=LEFT,bg="#a9acb6",
                        font=("times new roman", 15, "bold",), ).place(x=700, y=158)

        txtstart = DateEntry(frame, width=11, bg="#a9a9a9", date_pattern='yyyy-MM-dd', font=("", 12), textvariable=t4)
        txtstart.place(x=510, y=160)
        t4.set('')
        
        txtend = DateEntry(frame, width=11, bg="#a9a9a9", date_pattern='yyyy-MM-dd', font=("", 12), textvariable=t5)
        txtend.place(x=800, y=160)
        t5.set('')
        
        txtsearch = Entry(frame, width=20, bg="#a9a9a9", font=("", 12), textvariable=t6)
        txtsearch.place(x=5, y=158)

        Button(frame, text="Filter", command=filter, font=("", 10, "bold",), bg="#1b6453", fg="#c1cdc1",
                    width=15).place(x=1125, y=130)

        Button(frame, text="Search", bg="#003f87", fg="#eab5c5", width=20, command = search).place(x=200, y=155)

        Button(frame, text="Ok", bg="#003f87", fg="#eab5c5", width= 5, command = display_role,).place(x=400, y=88)
        Button(frame, text="Ok", bg="#003f87", fg="#eab5c5", width= 5, command = display_specialist,).place(x=795, y=88)


        Button(frame, text="Generate Report", bg="#003f87", fg="#eab5c5", width= 19, command = print_report,).place(x=1125, y=170)

        Button(frame, text="Back", command=back, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=50, y=50)

 # ===============================================Create table==================================================
        tv = ttk.Treeview(frame2, columns=(1, 2, 3, 4, 5, 6, 7, 8, 9), show="headings", height="5")

        xscrollbar = ttk.Scrollbar(frame2, orient="horizontal", command=tv.xview)
        xscrollbar.pack(side=BOTTOM, fill="x")
        yscrollbar = ttk.Scrollbar(frame2, orient=VERTICAL, command=tv.yview)
        yscrollbar.pack(side=RIGHT, fill=Y)

        tv.configure(xscrollcommand=xscrollbar.set)
        tv.configure(yscrollcommand=yscrollbar.set)

        tv.column(1, width=100)
        tv.column(2, width=100)
        tv.column(3, width=100)
        tv.column(4, width=50)
        tv.column(5, width=100)
        tv.column(6, width=100)
        tv.column(7, width=100)
        tv.column(8, width=100)
        tv.column(9, width=100)
        

        tv.heading(1, text="Date Recorded")
        tv.heading(2, text="Department")
        tv.heading(3, text="Role")
        tv.heading(4, text="Staff Id")
        tv.heading(5, text="Spacialist Name")
        tv.heading(6, text="Patient Card No")
        tv.heading(7, text="Patient Name")
        tv.heading(8, text="Queue No.")
        tv.heading(9, text="Status")
      

        tv.pack(fill=BOTH, expand=1)

# root= Tk()
# Reports(root, 'AD001')
# root.mainloop()