from datetime import datetime

from tkinter import *
import mysql.connector
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import messagebox

from common import calculate_age, get_incoming_patient, get_current_department, get_next_patient

from common import get_user
class Pharmacy:
    def __init__(self, root, staff_id):
        self.root=root
        self.root.title("Pharmacy")
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        self.root.geometry("{}x{}+0+0".format(screen_width, screen_height))

        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="password#123",
            database = "hospital_db"
        )
        c = conn.cursor()

        t1 = StringVar()
        t2 = StringVar()
        t3 = StringVar()
        t4 = StringVar()
        t5 = StringVar()
        t6 = StringVar()
        t7 = StringVar()
        t8 = StringVar()
        t9 = StringVar()

        frame = Frame(root, )
        frame.pack(fill=BOTH, expand=True, padx=(0, 0))


        def clear_pharmacy_entries():
            txtprescription_note.delete('1.0', END)


        def get_prescription_note(card_no):
            prescription_note = ''
            print("Prescription note card no", card_no)
            query = "SELECT prescription FROM visit WHERE card_no LIKE '{}' ORDER BY date desc".format(card_no)
            c.execute(query)
            entries = c.fetchall()
            print("Referral",entries[0])
            prescription_note = entries[0][0]
            print('Found Prescription_note note', type(prescription_note), prescription_note)

            return prescription_note


        def display_prescription_for_patient(card_no):
            prescription_note = get_prescription_note(card_no)
            print("prescription_note")
            txtprescription_note.insert('1.0', prescription_note)


        # Call next patient
        def call_next(staff_id):
            no_of_waiting_patients = ''
            current_patient_queue_no = ''
            current_patient_name = None
            current_patient = []
            incoming_patient, count = get_incoming_patient(staff_id)
            no_of_waiting_patients = count

            if not incoming_patient:
                return
            current_patient_queue_no = int(incoming_patient[2])
            current_patient_name = incoming_patient[1]

            if no_of_waiting_patients <= 0:
                no_of_waiting_patients = 0
            
            if current_patient_queue_no <= 0:
                current_patient_queue_no = 0
                current_patient_name = None

            current_patient_card_no = incoming_patient[0]

            print("current_patient_card_no", current_patient_card_no)

            query3 = "SELECT first_name, last_name, other_name, date_of_birth, gender FROM patient_detail WHERE card_no LIKE '" + current_patient_card_no + "' "
            c.execute(query3)
            patient = c.fetchall()
            current_patient_name = str(patient[0][0]) + ' ' +  str(patient[0][1]) + ' ' + str(patient[0][2])
            date_of_birth = patient[0][3]
            dob = datetime.fromisoformat(date_of_birth)
            age = calculate_age(dob)
            gender = patient[0][4]
            status = incoming_patient[3]
            
            display_prescription_for_patient(current_patient_card_no)
            

            current_patient.append(no_of_waiting_patients)
            current_patient.append(current_patient_queue_no)
            current_patient.append(current_patient_name)
            current_patient.append(age)
            current_patient.append(gender)
            current_patient.append(current_patient_card_no)
            current_patient.append(status)

            return current_patient


        def call_patient():
            try:
                next_patient_details = call_next(staff_id)
                t1.set(next_patient_details[0])
                t2.set(next_patient_details[1])
                t3.set(next_patient_details[2])
                t4.set(next_patient_details[3])
                t5.set(next_patient_details[4])
                t6.set(next_patient_details[5])
                t9.set(next_patient_details[6])

            except TypeError:
                return

        def update_current_patient_queue_status_to_closed(department, card_no, staff_id):
            status = 'CLOSED'
            query = "UPDATE queue SET status ='{}' WHERE patient_card_no LIKE '{}' AND staff_id LIKE '{}' AND department LIKE '{}'".format(status, card_no, staff_id, department)
            print(query)
            c.execute(query)
            conn.commit()
        
        def update_current_queue_status(status, staff_id, card_no):
            query3 = "UPDATE queue SET status = '{}' WHERE staff_id LIKE '{}' AND patient_card_no LIKE '{}'".format(status, staff_id, card_no)
            c.execute(query3)
            conn.commit()

        def skip_current():
            card_no = t6.get()
            status = 'SKIPPED'
            if messagebox.askyesno('SKIP!','Do you want to skip the current patient from taking too long?'):
                update_current_queue_status(status, staff_id, card_no)
                messagebox.showinfo('SKIPPED!',
                    'The patient has been skipped. \n'
                    'Call the next patient.')
            else:
                return

        def end_visit():
            card_no = t6.get()
            department = get_current_department(card_no, staff_id)
            update_current_patient_queue_status_to_closed(department, card_no, staff_id)
            messagebox.showinfo('DONE!',
                'Visit closed. \n'
                'Call next patient.')
            clear_pharmacy_entries()

        def next_patient():
            frame.destroy()
            from pharmacy import Pharmacy
            Pharmacy(root, staff_id)
        
        def exit_pharmacy():
            frame.destroy()
            import usertype
            usertype.UserType(root)
        
        Label(frame, text= get_user(staff_id), font=("times new roman", 40, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=500, y=5)

        Label(frame, text="In Queue:", font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=5, y=100)
        Label(frame,  textvariable = t1, font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=110, y=100)

        Label(frame, text = "Patient Queue No:",font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=150, y=100)
        Label(frame, textvariable = t2 ,font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=315, y=100)

        Label(frame, text = "Card No:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=370, y=100)
        Label(frame, textvariable = t6, font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=460, y=100)
        
        Label(frame, text = "Patient Name:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=570, y=100)
        Label(frame, textvariable = t3, font=("times new roman", 15, "bold", "italic"), width=30,
                        relief=GROOVE).place(x=700, y=100)

        Label(frame, text = "Patient Age:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=1040, y=100)
        Label(frame, textvariable = t4, font=("times new roman", 15, "bold", "italic"), width=5,
                        relief=GROOVE).place(x=1180, y=100)
        
        Label(frame, text = "Patient Gender:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=1040, y=140)
        Label(frame, textvariable = t5, font=("times new roman", 15, "bold", "italic"),  width=9,
                        relief=GROOVE).place(x=1180, y=140)

        Label(frame, text = "Status", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=600, y=140)
        Label(frame, textvariable = t9, font=("times new roman", 15, "bold", "italic"), width=15,
                        relief=GROOVE).place(x=670, y=140)
        
        Label(frame, text = "Prescription Note:", font = 20, relief=GROOVE).place(x=5, y=280)
        txtprescription_note = scrolledtext.ScrolledText(frame,font=("Times New Roman", 15))
        txtprescription_note.place(x=250, y=280, width=350, height=200)

        Button(frame, text="Skip Current Calling", command=skip_current, font=("", 10, "bold",), bg="#8b4c39", fg="#f6c9cc",
                    width=15).place(x=20, y=50)

        Button(frame, text="OK", command=end_visit, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=500, y=550)

        Button(frame, text="Next", command=next_patient, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=800, y=550)

        Button(frame, text="Exit", command=exit_pharmacy, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=20, y=10)
    
        call_patient()

# root = Tk()
# Pharmacy(root, 'PH001')
# root.mainloop()
