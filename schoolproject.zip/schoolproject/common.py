import uuid

from datetime import datetime, date
from tkinter import *
from tkinter import messagebox
import mysql.connector

conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="password#123",
        database = "hospital_db"
    )
c = conn.cursor()


def get_patient_name(card_no):
    c = conn.cursor()
    query1 = "SELECT first_name, last_name, other_name FROM patient_detail WHERE card_no LIKE '{}'".format(card_no)
    print(query1)
    c.execute(query1)
    entries = c.fetchall()
    print("Patient Details",entries)
    name = ""
    for entry in entries:
        name = entry[0] + " " + entry[1] + " " + entry[2]

    print("Patient to be queued Name",name)

    return name


def get_user(staff_id):
    c = conn.cursor()
    query3 =  "SELECT title, first_name, last_name FROM employee_detail WHERE staff_id like '{}'".format(staff_id)
    c.execute(query3)

    result = c.fetchall()
    user_details = result[0]
    user = str(user_details[0]) + ' ' + str(user_details[1]) + ' ' + str(user_details[2])

    return user


def calculate_age(dob):
    today = date.today()
    return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))


def get_dpt():
    c = conn.cursor()
    c.execute("SELECT name FROM department GROUP BY name ORDER BY name asc")
    departments = []
    rows = c.fetchall()
                    
    for row in rows:
        departments.append(row[0])

    return departments


def get_role():
    c = conn.cursor()
    c.execute("SELECT name FROM role GROUP BY name ORDER BY name asc")
    roles = []
    rows = c.fetchall()

    for row in rows:
        roles.append(row[0])
    
    return roles


def get_staff_name(staff_id):
    query = "SELECT title, first_name, last_name FROM employee_detail WHERE staff_id LIKE '{}'".format(staff_id)
    c.execute(query)
    details = c.fetchall()

    name = ""
    for detail in details:
        name = detail[0] + " " + detail[1] + " " + detail[2]

    return name


def queue_patient(department, role, assigned_specialist_staff_id, assigned_specialist_name, card_no, patient_name, new_queue, status, staff_id):
    """Add queue entry to the queue table."""
    id = str(uuid.uuid4())
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    card_no = card_no

    query3 = "INSERT INTO queue(id, date, department, role, staff_id, specialist_name, patient_card_no, patient_name, queue_no, status)  VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
    val = (id, date, department, role, assigned_specialist_staff_id, assigned_specialist_name, card_no, patient_name, new_queue, status)
    c.execute(query3,val)
    conn.commit()
    check_patient_name_in_queue(card_no, staff_id)

    messagebox.showinfo('Ok','Patient added to queue')

def terminate_previous_visit(card_no):
    status = 'CLOSED FOR ANOTHER VISIT'
    query = "UPDATE queue SET status ='{}' WHERE patient_card_no LIKE '{}'".format(status, card_no)
    c.execute(query)
    conn.commit()


def queue_emergency(department, role, card_no):
    c = conn.cursor()
    id = str(uuid.uuid4())
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    card_no = card_no.upper()
    print(card_no)
    status = 'EMERGENCY'

    # Get the name of patient to be queued
    patient_name = 'John Doe'

    # Get all specialists in the selected department with the given role
    query = "SELECT * FROM specialist WHERE department LIKE '" + department + "' AND role LIKE '" + role + "'"
    c.execute(query)

    specialists = c.fetchall()
    conn.commit()

    #  Check if a specialist exists in the given department and role to be queued
    if specialists == []:
        messagebox.showerror('ERROR', 'There is no {} under {}'.format(role, department))
        return
    else:
        pass
    # Initialize id of the specialist with the least number of patients in queue (least_id)
    # Initialize name of speacialist with the least number of patients in queue (speacialist_name)
    # Initialize the staff_id of the speacialist to whom the patient will be queued as None
    # Initialize the least number of patients in queue as positive infinity (smallest_queue)
    # Initialize the legth of the queue of the assigned specialist
    assigned_least_id = None
    assigned_specialist_staff_id = None
    assigned_specialist_name = None
    assigned_specialist_queue_length = float("inf")
    current_queue_number = None

    # Loop over the specialists and check if the length of their queue is less than the
    # smallest value starting from positive infinity.
    # If the value is less that positive infinity it is set as the least value and the speacialist identified
    # The loop continues and compares the queue length of the currently looping specialist with the.
    # length of the smallest value yet.
    # The least value is assigned the smallest value and the specialist identified
    # as the one to whom the patient will be queued.

    print("Specialists",specialists)
    
    for specialist in specialists:
        id = specialist[0]
        staff_id = specialist[4]
        queue = int(specialist[5])
        queue_length = int(specialist[6])

        if queue_length < assigned_specialist_queue_length:
            assigned_least_id = id
            assigned_specialist_staff_id = staff_id
            current_queue_number = queue
            assigned_specialist_queue_length = queue_length
    
    print("Assigned least id",assigned_least_id)
    print("Assigned specialist staff id",assigned_specialist_staff_id)
    print("Current Queue Number:",current_queue_number)
    print("The smallest queue has:",assigned_specialist_queue_length)

    new_queue = str(int(current_queue_number) + 1)

    new_queue_length = str(int(assigned_specialist_queue_length) + 1)

    # Update specilists by updating the queue of the selected specialist based on their id
    query1 = "UPDATE specialist SET queue = '" + new_queue +"', queue_length = '" + new_queue_length +"'  WHERE id LIKE '" + assigned_least_id +"'"
    c.execute(query1)
    conn.commit()

    # Get name of the specialist to whom the patient has been assigned
    assigned_specialist_name = get_staff_name(assigned_specialist_staff_id)

    print("Specialist Name:",assigned_specialist_name)

    if not patient_in_queue(card_no, department):
        queue_patient(department, role, assigned_specialist_staff_id, assigned_specialist_name, card_no, patient_name, new_queue, status, staff_id)
    else:
        if messagebox.askyesno('EXISTS!','The patient is already queued \n'
        'Do you want to terminate their previous visit and start a new one?'):
            terminate_previous_visit(card_no)
            queue_patient(department, role, assigned_specialist_staff_id, assigned_specialist_name, card_no, patient_name, new_queue, status, staff_id)
        
        else:
            return

def queue(department, role, card_no):
    c = conn.cursor()
    id = str(uuid.uuid4())
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    card_no = card_no.upper()
    print(card_no)
    status = 'INCOMING'

    # Get the name of patient to be queued
    patient_name = get_patient_name(card_no)

    # Get all specialists in the selected department with the given role
    query = "SELECT * FROM specialist WHERE department LIKE '" + department + "' AND role LIKE '" + role + "'"
    c.execute(query)

    specialists = c.fetchall()
    conn.commit()

    #  Check if a specialist exists in the given department and role to be queued
    if specialists == []:
        messagebox.showerror('ERROR', 'There is no {} under {}'.format(role, department))
        return
    else:
        pass
    # Initialize id of the specialist with the least number of patients in queue (least_id)
    # Initialize name of speacialist with the least number of patients in queue (speacialist_name)
    # Initialize the staff_id of the speacialist to whom the patient will be queued as None
    # Initialize the least number of patients in queue as positive infinity (smallest_queue)
    # Initialize the legth of the queue of the assigned specialist
    assigned_least_id = None
    assigned_specialist_staff_id = None
    assigned_specialist_name = None
    assigned_specialist_queue_length = float("inf")
    current_queue_number = None

    # Loop over the specialists and check if the length of their queue is less than the
    # smallest value starting from positive infinity.
    # If the value is less that positive infinity it is set as the least value and the speacialist identified
    # The loop continues and compares the queue length of the currently looping specialist with the.
    # length of the smallest value yet.
    # The least value is assigned the smallest value and the specialist identified
    # as the one to whom the patient will be queued.

    print("Specialists",specialists)
    
    for specialist in specialists:
        id = specialist[0]
        staff_id = specialist[4]
        queue = int(specialist[5])
        queue_length = int(specialist[6])

        if queue_length < assigned_specialist_queue_length:
            assigned_least_id = id
            assigned_specialist_staff_id = staff_id
            current_queue_number = queue
            assigned_specialist_queue_length = queue_length
    
    print("Assigned least id",assigned_least_id)
    print("Assigned specialist staff id",assigned_specialist_staff_id)
    print("Current Queue Number:",current_queue_number)
    print("The smallest queue has:",assigned_specialist_queue_length)

    new_queue = str(int(current_queue_number) + 1)

    new_queue_length = str(int(assigned_specialist_queue_length) + 1)

    # Update specilists by updating the queue of the selected specialist based on their id
    query1 = "UPDATE specialist SET queue = '" + new_queue +"', queue_length = '" + new_queue_length +"'  WHERE id LIKE '" + assigned_least_id +"'"
    c.execute(query1)
    conn.commit()

    # Get name of the specialist to whom the patient has been assigned
    assigned_specialist_name = get_staff_name(assigned_specialist_staff_id)

    print("Specialist Name:",assigned_specialist_name)

    if not patient_in_queue(card_no, department):
        queue_patient(department, role, assigned_specialist_staff_id, assigned_specialist_name, card_no, patient_name, new_queue, status, staff_id)
    else:
        if messagebox.askyesno('EXISTS!','The patient is already queued \n'
        'Do you want to terminate their previous visit and start a new one?'):
            terminate_previous_visit(card_no)
            queue_patient(department, role, assigned_specialist_staff_id, assigned_specialist_name, card_no, patient_name, new_queue, status, staff_id)
        
        else:
            return
 

def patient_in_queue(card_no, department):
    in_queue = False
    query = "SELECT status FROM queue WHERE patient_card_no LIKE '{}' AND department LIKE '{}' AND status LIKE 'INCOMING' OR status LIKE 'EMERGENCY'".format(card_no, department)
    c.execute(query)

    entries = c.fetchall()
    for entry in entries:
        status = entry[0]
        if status == 'INCOMING' or status == 'EMERGENCY' or status == 'RETURNED':
            in_queue = True
    return in_queue


def check_patient_name_in_queue(card_no, staff_id):
    name = ''
    status1 = 'INCOMING'
    status2 = 'EMERGENCY'
    query = "SELECT patient_name from queue where patient_card_no LIKE '{}' AND staff_id LIKE '{}' AND status LIKE '{}' OR status LIKE '{}' ORDER BY date DESC".format(card_no, staff_id, status1, status2)
    c.execute(query)
    entries = c.fetchall()
    if entries != []:
        for entry in entries:
            name = entry[0]

        if name == '':
            patient_name = get_patient_name(card_no)
            query = "UPDATE queue SET patient_name = '{}' WHERE patient_card_no LIKE '{}' AND staff_id LIKE '{}' AND status LIKE '{}' OR status LIKE '{}'".format(patient_name, card_no, staff_id, status1, status2)
            c.execute(query)
            conn.commit()
        else:
            pass


def get_incoming_patient(staff_id):
    details = []
    c = conn.cursor()
    status1 = 'EMERGENCY'
    status2 = 'INCOMING'
    status3 = 'RETURNING'
    query1 =  "SELECT patient_card_no, patient_name, queue_no, status FROM queue WHERE staff_id like '{}' AND status LIKE '{}' ORDER BY date ASC".format(staff_id, status1)
    query2 =  "SELECT patient_card_no, patient_name, queue_no, status FROM queue WHERE staff_id like '{}' AND status LIKE '{}' ORDER BY date ASC".format(staff_id, status2)
    query3 =  "SELECT patient_card_no, patient_name, queue_no, status FROM queue WHERE staff_id like '{}' AND status LIKE '{}' ORDER BY date ASC".format(staff_id, status3)
    print(query1)
    c.execute(query1)
    edetails = c.fetchall()
    conn.commit()
    if edetails == []:
        c.execute(query2)
        idetails = c.fetchall()
        conn.commit()
        if idetails == []:
            c.execute(query3)
            rdetails = c.fetchall()
            conn.commit()
            if rdetails == []:
                messagebox.showinfo('WAIT','You have no Patients in queue')
                return
            else:
                details = rdetails
        else:
            details = idetails
    else:
        details = edetails

    count = len(details) 

    print('Details of the incoming patient',details[0])
    return details[0], count

def get_next_patient(staff_id, incoming_card_no):
    c = conn.cursor()
    status1 = 'INCOMING'
    status2 = 'RETURNING'
    query =  "SELECT patient_card_no, patient_name, queue_no, status FROM queue WHERE staff_id LIKE '{}' AND patient_card_no LIKE '{}' AND status LIKE '{}' OR status LIKE '{}' ORDER BY date ASC".format(staff_id, incoming_card_no , status1, status2)
    print(query)
    c.execute(query)
    details = c.fetchall()
    print(details)

    if details == []:
        messagebox.showinfo('WAIT','You have no Patients in queue')
        return

    print('Details of the incoming patient',details[0])
    return details[0]

def get_emergency_patient(staff_id):
    current_patient = []
    query2 =  "SELECT * FROM queue WHERE staff_id like '{}' AND status LIKE '{}'".format(staff_id, 'EMERGENCY')
    c.execute(query2)
    queue_details = c.fetchall()

    if queue_details == []:
        messagebox.showinfo('WAIT','You have no Patients in queue')
        return

    current_patient.append(queue_details[0][6])
    current_patient.append(queue_details[0][7])
    current_patient.append(queue_details[0][8])

    return current_patient


def get_referred_patient(staff_id):
    current_patient = []
    query2 =  "SELECT * FROM queue WHERE staff_id like '{}' AND status LIKE '{}'".format(staff_id, 'REFERRED')
    c.execute(query2)
    queue_details = c.fetchall()

    if queue_details == []:
        messagebox.showinfo('WAIT','You have no Patients in queue')
        return

    current_patient.append(queue_details[0][6])
    current_patient.append(queue_details[0][7])
    current_patient.append(queue_details[0][8])

    return current_patient


def get_current_department(card_no, staff_id):
    department = ''
    query = "SELECT department FROM queue WHERE patient_card_no LIKE '{}' AND staff_id LIKE '{}'".format(card_no, staff_id)
    c.execute(query)

    entries = c.fetchall()
    conn.commit()
    for entry in entries:
        department = entry[0]

    print("Closed Department", department)

    return(department)


