import uuid
import datetime
from datetime import datetime, date


from tkinter import *
import tkinter
import mysql.connector
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import messagebox

from mysql.connector.utils import _parse_os_release
from common import get_user, get_dpt, queue, get_role, get_incoming_patient , calculate_age, get_next_patient

class Doctor:
    def __init__(self, root, staff_id):
        self.root=root
        self.root.title("Doctor")
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        self.root.geometry("{}x{}+0+0".format(screen_width, screen_height))

        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="password#123",
            database = "hospital_db"
        )
        c = conn.cursor()

        t1 = StringVar()
        t2 = StringVar()
        t3 = StringVar()
        t4 = StringVar()
        t5 = StringVar()
        t6 = StringVar()
        t7 = StringVar()
        t8 = StringVar()
        t9 = StringVar()
        t10 = StringVar()
        t11 = StringVar()

        def get_test(card_no):
            test_details = []
            query = "SELECT visit_note, referral_note, results, card_no FROM visit WHERE card_no LIKE '{}' ORDER BY date DESC".format(card_no)
            print(query)
            c.execute(query)

            entries = c.fetchall()
            print("ENTRIES",entries)
            for entry in entries:
                test_details.append(entry[0])
                test_details.append(entry[1])
                test_details.append(entry[2])
            
            print(test_details)
            return test_details
            
        
        def update_diagnosis_for_returning_patient(card_no):
            if t9.get() == 'RETURNING':
                visit_note = get_test(card_no)[0]
                txtvisitnote.insert('1.0', visit_note)
                referral_note = get_test(card_no)[1]
                txtreferralnote.insert('1.0', referral_note)
                diagnosis =get_test(card_no)[2]
                txtdiagnosis.insert('1.0', diagnosis)

        def call_next(staff_id):
            no_of_waiting_patients = ''
            current_patient_queue_no = ''
            current_patient_name = None
            current_patient = []
            incoming_patient, count = get_incoming_patient(staff_id)
            no_of_waiting_patients = count

            if not incoming_patient:
                return
            current_patient_queue_no = int(incoming_patient[2])
            current_patient_name = incoming_patient[1]

            if no_of_waiting_patients <= 0:
                no_of_waiting_patients = 0
            
            if current_patient_queue_no <= 0:
                current_patient_queue_no = 0
                current_patient_name = None

            current_patient_card_no = incoming_patient[0]

            print("current_patient_card_no", current_patient_card_no)

            query3 = "SELECT first_name, last_name, other_name, date_of_birth, gender FROM patient_detail WHERE card_no LIKE '" + current_patient_card_no + "' "
            c.execute(query3)
            patient = c.fetchall()
            current_patient_name = str(patient[0][0]) + ' ' +  str(patient[0][1]) + ' ' + str(patient[0][2])
            date_of_birth = patient[0][3]
            dob = datetime.fromisoformat(date_of_birth)
            age = calculate_age(dob)
            gender = patient[0][4]
            status = incoming_patient[3]
            
            update_diagnosis_for_returning_patient(current_patient_card_no)
            

            current_patient.append(no_of_waiting_patients)
            current_patient.append(current_patient_queue_no)
            current_patient.append(current_patient_name)
            current_patient.append(age)
            current_patient.append(gender)
            current_patient.append(current_patient_card_no)
            current_patient.append(status)

            return current_patient

        def call_patient(staff_id):
            try:
                no_of_waiting_patients = call_next(staff_id)[0]
                current_patient_queue_no = call_next(staff_id)[1]
                current_patient_name = call_next(staff_id)[2]
                age = call_next(staff_id)[3]
                gender = call_next(staff_id)[4]
                current_patient_card_no = call_next(staff_id)[5]
                status = call_next(staff_id)[6]

                t1.set(no_of_waiting_patients)
                t2.set(current_patient_queue_no)
                t3.set(current_patient_name)
                t4.set(age)
                t5.set(gender)
                t8.set(current_patient_card_no)
                t9.set(status)

            except TypeError:
                return

        def entry_next():
            pass

        def clear_entries():
            txtvisitnote.delete(1.0, END)
            txtdiagnosis.delete(1.0, END)
            txtprescription.delete(1.0, END)
            txtreferralnote.delete(1.0, END)
            t6.set('')
            t7.set('')

        def update_current_queue_status(status, staff_id, card_no):
            query = "UPDATE queue SET status = '{}' WHERE staff_id LIKE '{}' AND patient_card_no LIKE '{}'".format(status, staff_id, card_no)
            c.execute(query)
            conn.commit()
            print("Update to closed query", query)
        
        def update_current_queue_length(new_queue_length):
            query2 = "UPDATE specialist SET queue_length = '" + new_queue_length +"' WHERE staff_id LIKE '" + staff_id +"'"
            c.execute(query2)
            conn.commit()
        
        def get_new_queue_length():
            new_queue_length = ''
            query1 = "SELECT queue_length FROM specialist WHERE staff_id LIKE '" + staff_id + "'"
            c.execute(query1)
            output = c.fetchall()
            for value in output:
                new_queue_length = str(int(value[0]) - 1)

            return new_queue_length
            
        def update_current_queue(status, staff_id, card_no):
            new_queue_length = get_new_queue_length()
            update_current_queue_length(new_queue_length)
            update_current_queue_status(status, staff_id, card_no)


        def add_visit_with_referal_note(card_no, visit_note, referral_note):
            id = str(uuid.uuid4())
            date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            query1 = "INSERT INTO visit(id, date, card_no, staff_id, visit_note, referral_note)  VALUES(%s, %s, %s, %s, %s, %s)"
            val = (id, date, card_no, staff_id, visit_note, referral_note)
            c.execute(query1, val)
            conn.commit()

        def get_visit_id(card_no):
            id = ''
            query = "SELECT id FROM visit WHERE card_no LIKE '{}' ORDER BY DATE desc".format(card_no)
            c.execute(query)
            entries = c.fetchall()    

            for entry in entries:
                id =  entry[0]

            return id

        def update_visit_note(visit_note, diagnosis, prescription, card_no):
            id = get_visit_id(card_no)
            query = "UPDATE visit SET visit_note = '{}', diagnosis = '{}', prescription = '{}' WHERE id LIKE '{}'".format(visit_note, diagnosis, prescription, id)
            c.execute(query)
            conn.commit()


        def add_visit_with_diagnosis(card_no, visit_note, diagnosis, prescription):
            id = str(uuid.uuid4())
            date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            status = t9.get()

            if diagnosis == 'RETURNING':
                update_visit_note(visit_note, diagnosis, prescription, card_no)
                return

            query1 = "INSERT INTO visit(id, date, card_no, staff_id, visit_note, diagnosis, prescription)  VALUES(%s, %s, %s, %s, %s, %s, %s)"
            val = (id, date, card_no, staff_id, visit_note, diagnosis, prescription)
            c.execute(query1, val)
            conn.commit()


        def refer():
            visit_note = txtvisitnote.get("1.0", tkinter.END)
            referral_note = txtreferralnote.get("1.0", tkinter.END)
            department = t6.get()
            role = t7.get()
            card_no = t8.get()
            status = 'REFERRED'

            if len(visit_note) >2 and len(referral_note) > 2 and department !='' and role !='':
                add_visit_with_referal_note(card_no, visit_note, referral_note)
                queue(department, role, card_no)
                update_current_queue(status, staff_id, card_no)
                messagebox.showinfo('REFERRED!',
                    'The patient has been referred.\n'
                    'Call next patient')
                clear_entries()

            else:
                messagebox.showerror('ERROR!','Fill in the referral note, department and role')
                return
            
        
        def next_patient():
            frame.destroy()
            from doctor import Doctor
            Doctor(root, staff_id)


        def send_patient():
            visit_note = txtvisitnote.get("1.0", tkinter.END)
            diagnosis = txtdiagnosis.get("1.0", tkinter.END)
            prescription = txtprescription.get("1.0", tkinter.END)
            card_no = t8.get()
            department = 'PHARMACY'
            role = 'PHARMACIST'
            status = 'CLOSED'

            if len(visit_note) > 2 and len(diagnosis) >2:
                add_visit_with_diagnosis(card_no, visit_note, diagnosis,prescription)
                queue(department, role, card_no)
                update_current_queue(status, staff_id, card_no)
                clear_entries()
                
            else:
                messagebox.showerror('ERROR','Fill in the Visit Note and Specify the Diagnosis')
                return

        def skip_current():
            card_no = t8.get()
            status = 'SKIPPED'
            if messagebox.askyesno('SKIP!','Do you want to skip the current patient for taking too long?'):
                update_current_queue_status(status, staff_id, card_no)
            else:
                return

        def end_visit():
            card_no = t8.get()
            status = 'CLOSED'
            update_current_queue_status(status, staff_id, card_no)
            messagebox.showinfo('CLOSED!',
            'The patient visit has been closed.\n'
            'Call next patient')

        def exit_doctor():
            frame.destroy()
            import usertype
            usertype.UserType(root)


        frame = Frame(root)
        frame.pack(fill=BOTH, expand=True, padx=(0, 0))    

        Label(frame, text= get_user(staff_id), font=("times new roman", 40, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=500, y=5)

        Label(frame, text="In Queue:", font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=5, y=100)
        Label(frame,  textvariable = t1, font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=110, y=100)

        Label(frame, text = "Patient Queue No:",font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=150, y=100)
        Label(frame, textvariable = t2 ,font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=315, y=100)

        Label(frame, text = "Card No:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=370, y=100)
        Label(frame, textvariable = t8, font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=460, y=100)
        
        Label(frame, text = "Patient Name:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=570, y=100)
        Label(frame, textvariable = t3, font=("times new roman", 13, "bold", "italic"), width=32,
                        relief=GROOVE).place(x=700, y=100)

        Label(frame, text = "Patient Age:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=1040, y=100)
        Label(frame, textvariable = t4, font=("times new roman", 15, "bold", "italic"), width=5,
                        relief=GROOVE).place(x=1180, y=100)
        
        Label(frame, text = "Patient Gender:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=1040, y=140)
        Label(frame, textvariable = t5, font=("times new roman", 15, "bold", "italic"),  width=9,
                        relief=GROOVE).place(x=1180, y=140)

        Label(frame, text = "Status", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=600, y=140)
        Label(frame, textvariable = t9, font=("times new roman", 15, "bold", "italic"), width=15,
                        relief=GROOVE).place(x=670, y=140)

        Label(frame, text = "Visit Note:", font = 20, relief=GROOVE).place(x=5, y=180)
        txtvisitnote = scrolledtext.ScrolledText(frame, width=45, height=6,font=("Times New Roman", 15))
        txtvisitnote.place(x=150, y=180)

        Label(frame, text = "Diagnosis:", font = 20, relief=GROOVE).place(x=5, y=360)
        txtdiagnosis=scrolledtext.ScrolledText(frame, width=45, height=6,font=("Times New Roman", 15))
        txtdiagnosis.place(x=150, y=360)

        Label(frame, text = "Referral Note:", font = 20, relief=GROOVE).place(x=660, y=200)
        txtreferralnote=scrolledtext.ScrolledText(frame, width=45, height=6, font=("Times New Roman", 15))
        txtreferralnote.place(x=800, y=200,)

        Label(frame, text="Department:", compound=LEFT, bg="#a9acb6",
                        font=("times new roman", 12, "bold",), ).place(x=800, y=360)
        txtdpt = ttk.Combobox(frame, width=30, textvariable=t6,)
        txtdpt.place(x=925, y=360)
        txtdpt.bind("<Return>",entry_next)
        txtdpt['values'] = get_dpt()

        Label(frame, text="Specialist:", compound=LEFT, bg="#a9acb6",
                        font=("times new roman", 12, "bold",), ).place(x=800, y=400)
        txtspecialist = ttk.Combobox(frame, width=30, textvariable=t7,)
        txtspecialist.place(x=925, y=400)
        txtspecialist.bind("<Return>",entry_next)
        txtspecialist['values'] = get_role()

        Label(frame, text = "Prescription:", font = 20, relief=GROOVE).place(x=5, y=520)
        txtprescription = scrolledtext.ScrolledText(frame, width=45, height=6,font=("Times New Roman", 15))
        txtprescription.place(x=150, y=520,)

        Button(frame, text="Refer", command=refer, font=("", 10, "bold",), bg="#068481", fg="#b0c4de", width=15).place(
            x=1100, y=450)
        
        Button(frame, text="Send", command=send_patient, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=650, y=650)
        
        Button(frame, text="Next", command=next_patient, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=850, y=650)

        Button(frame, text="End Current Patient Visit", command=end_visit, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=19).place(x=1150, y=50)

        Button(frame, text="Skip Current Calling", command=skip_current, font=("", 10, "bold",), bg="#8b4c39", fg="#f6c9cc",
                    width=15).place(x=20, y=50)
        
        Button(frame, text="Exit", command=exit_doctor, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=20, y=10)

        call_patient(staff_id)

# root = Tk()
# Doctor(root,'A003')
# root.mainloop()
