from tkinter import *
import mysql.connector

class UserType:
	def __init__(self,root):
		self.root=root
		self.root.title("User Type")
		screen_width = root.winfo_screenwidth()
		screen_height = root.winfo_screenheight()
		self.root.geometry("{}x{}+0+0".format(screen_width, screen_height))



		conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="password#123",
			database = "hospital_db"
        )
		c = conn.cursor()

		var=StringVar()


		def login_admin():
			user_type = 'ADMIN'
			frame.destroy()
			import login
			login.Login(root, user_type)

		def login_reception():
			user_type = 'RECEPTIONIST'
			frame.destroy()
			import login
			login.Login(root, user_type)

		def login_doctor():
			user_type = 'DOCTOR'
			frame.destroy()
			import login
			login.Login(root, user_type)

		def login_lab():
			user_type = "LAB TECHNICIAN"
			frame.destroy()
			import login
			login.Login(root, user_type)
			

		def login_pharmacist():
			user_type = "PHARMACIST"
			frame.destroy()
			import login
			login.Login(root, user_type)


		frame = Frame(root, )
		frame.pack(fill=BOTH, expand=True, padx=(0, 0))

		formlbl = Label(frame, text="Admin Form", font=("times new roman", 40, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=500, y=5)
		Radiobutton(frame,text="Admin",variable=var,value="admin", command = login_admin, font=10).place(relx=0.4,rely=0.1)
		Radiobutton(frame,text="Reception",variable=var,value="receptionist", command = login_reception, font=10).place(relx=0.4,rely=0.2)
		Radiobutton(frame,text="Doctor",variable=var,value="doctor", command = login_doctor, font=10).place(relx=0.4,rely=0.3)
		Radiobutton(frame,text="Lab Technician",variable=var,value="lab", command = login_lab, font=10).place(relx=0.4,rely=0.4)
		Radiobutton(frame,text="Pharmacist",variable=var,value="pharmacist", command = login_pharmacist, font=10).place(relx=0.4,rely=0.5)


# root= Tk()
# UserType(root)
# root.mainloop()