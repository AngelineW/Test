from openpyxl import Workbook
import pandas as pd
import mysql.connector

from openpyxl import load_workbook
import xlsxwriter
from openpyxl.workbook.protection import WorkbookProtection
import os
import sys
from openpyxl import Workbook
from openpyxl import load_workbook

from datetime import datetime


def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
        os.chdir(sys._MEIPASS)
        os.system('Database Entries Report.xlsx')
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

workbook = Workbook()
sheet = workbook.active

if os.path.exists('Database Entries Report.xlsx'):
    workbook = load_workbook(filename='Database Entries Report.xlsx', read_only=False)
else:
    workbook = xlsxwriter.Workbook('Database Entries Report.xlsx')

conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="password#123",
            database = "hospital_db"
        )

df1=pd.read_sql_query("SELECT * from patient_detail",conn)
df2=pd.read_sql_query("SELECT staff_id, title, first_name, last_name, other_name, user_type, username from employee_detail",conn)
df3=pd.read_sql_query("SELECT * from department",conn)
df4=pd.read_sql_query("SELECT * from role",conn)
df5=pd.read_sql_query("SELECT * from specialist",conn)
df6=pd.read_sql_query("SELECT * from queue",conn)
df7=pd.read_sql_query("SELECT * from visit",conn)

with pd.ExcelWriter('Database Entries Report.xlsx') as writer:
    df1.to_excel(writer, sheet_name='Patient Details')
    df2.to_excel(writer, sheet_name='Employee Details')
    df3.to_excel(writer, sheet_name='Departments')
    df4.to_excel(writer, sheet_name='Roles')
    df5.to_excel(writer, sheet_name='Specialists')
    df6.to_excel(writer, sheet_name='Queues')
    df7.to_excel(writer, sheet_name='Visits')

workbook.close()