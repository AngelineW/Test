from tkinter import *
import mysql.connector
from tkinter import messagebox

class Login:
    def __init__(self, root, user_type):
        self.root = root
        self.root.title("HOSPITAL QUEUEING SYSTEM")
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        self.root.geometry("{}x{}+0+0".format(screen_width, screen_height))
        self.root.configure(background="grey")

        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            
            password="password#123",
            database = "hospital_db"
        )
        c = conn.cursor()

        l1 = StringVar()
        l2 = StringVar()

        def login():
            c = conn.cursor()
            print(user_type)

            if l1.get() == '' or l2.get() == '':
                messagebox.showerror('ERROR', "All fields are required")
                return
            
            else:
                username = l1.get()
                password = l2.get()
                print(username)
                query = "SELECT user_type, staff_id, username, password FROM employee_detail WHERE username like '" + username + "'"
                print(query)
                c.execute(query)

                user = c.fetchall()

                if user == []:
                    messagebox.showerror('ERROR!', "Enter valid login details")
                    return

                print(password,user[0][3])
                if password == user[0][3]:
                    pass

                else:
                    messagebox.showerror('ERROR!', 'Invalid Login')
                    return

                usertype = user[0][0]

                if usertype == user_type:
                    messagebox.showinfo('Ok', "Proceeding as {}".format(user_type))
                    pass
                else:
                    messagebox.showerror('ERROR!', " You cannot login as {}".format(user_type))
                    return

                
                if user_type == "ADMIN":
                    staff_id = user[0][1]
                    frame.destroy()
                    import admin
                    admin.Admin(root, staff_id)

                elif user_type == "DOCTOR":
                    staff_id = user[0][1]
                    frame.destroy()
                    import doctor
                    doctor.Doctor(root, staff_id)

                elif user_type == "RECEPTIONIST":
                    staff_id = user[0][1]
                    frame.destroy()
                    import reception
                    reception.Reception(root, staff_id)

                elif user_type == "LAB TECHNICIAN":
                    staff_id = user[0][1]
                    frame.destroy()
                    import lab
                    lab.Lab(root, staff_id)

                elif user_type == "PHARMACIST":
                    staff_id = user[0][1]
                    frame.destroy()
                    import pharmacy
                    pharmacy.Pharmacy(root, staff_id)

                else:
                    messagebox.showerror('ERROR!', "Staff is not allocated")
                

        frame = Frame(root, )
        frame.pack(fill=BOTH, expand=True, padx=(0, 0))

        Label(frame, text="Login Here", font=("times new roman", 40, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=500, y=5)

        Label(frame, text="Username:", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, ).place(x=5, y=140)
        Entry(frame, font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, textvariable=l1).place(x=200, y=140)

        Label(frame, text="Password:", font=("times new roman", 20, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE, ).place(x=5, y=180)
        Entry(frame, font=("times new roman", 20, "bold", "italic"), bg="#a9acb6", show = "*",
                        fg="black", relief=GROOVE, textvariable=l2).place(x=200, y=180)                

        Button(frame, text="Login", command = login, font=("", 10, "bold",), bg="#068481", fg="#b0c4de", width=10).place(
            x= 300, y=220,)
        
# root = Tk()
# Login(root, 'Admin')
# root.mainloop()
