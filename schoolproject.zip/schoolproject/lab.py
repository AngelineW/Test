from tkinter import *
from tkinter import ttk
from tkinter import scrolledtext
from tkinter import messagebox
import mysql.connector

from datetime import datetime, date

from common import get_user, get_incoming_patient, calculate_age, get_current_department

class Lab:
    def __init__(self, root, staff_id):
        self.root=root
        self.root.title("Doctor")

        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        self.root.geometry("{}x{}+0+0".format(screen_width, screen_height))
        self.root.geometry("{}x{}+0+0".format(screen_width, screen_height))

        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="password#123",
            database = "hospital_db"
        )
        c = conn.cursor()

        t1 = StringVar()
        t2 = StringVar()
        t3 = StringVar()
        t4 = StringVar()
        t5 = StringVar()
        t6 = StringVar()
        t7 = StringVar()
        t8 = StringVar()
        t9 = StringVar()
        t10 = StringVar()
        t11 = StringVar()

        def get_referral_note(card_no):
            print("Referral note card no", card_no)
            referral_note = ''
            query = "SELECT referral_note FROM visit WHERE card_no LIKE '{}' ORDER BY date desc".format(card_no)
            c.execute(query)
            referral_notes = c.fetchall()
            print("Referral",referral_notes)
            for note in referral_notes[0]:
                referral_note = note
                print('Found Referral note', type(referral_note), referral_note)

            return referral_note
        
        def get_visit_id(card_no):
            visit_id = ''
            query = "SELECT id FROM visit WHERE card_no LIKE '{}' ORDER BY date desc".format(card_no)
            c.execute(query)
            ids = c.fetchall()
            print(ids)
            for id in ids:
                visit_id = id[0]

            return visit_id

        def get_referer_id(card_no):
            staff_id = ''
            query = "SELECT staff_id FROM queue WHERE patient_card_no LIKE '{}' AND status LIKE '{}'".format(card_no, 'REFERRED')
            c.execute(query)

            entries = c.fetchall()
            for entry in entries:
                staff_id = entry[0]

            return staff_id

        def update_referral_note_for_referred_patient(current_patient_card_no):
            referral_note = get_referral_note(current_patient_card_no)
            print("Referral note", referral_note)

            if referral_note == '':
                messagebox.showinfo('NOTE!','The patient was not referred to the lab')

            else:
                txtreferralnote.insert('1.0', referral_note)

        def call_next(staff_id):
            no_of_waiting_patients = ''
            current_patient_queue_no = ''
            current_patient_name = None
            current_patient = []
            incoming_patient, count = get_incoming_patient(staff_id)
            no_of_waiting_patients = count

            if not incoming_patient:
                return
            current_patient_queue_no = int(incoming_patient[2])
            current_patient_name = incoming_patient[1]

            if no_of_waiting_patients <= 0:
                no_of_waiting_patients = 0
            
            if current_patient_queue_no <= 0:
                current_patient_queue_no = 0
                current_patient_name = None

            current_patient_card_no = incoming_patient[0]

            print("current_patient_card_no", current_patient_card_no)

            query3 = "SELECT first_name, last_name, other_name, date_of_birth, gender FROM patient_detail WHERE card_no LIKE '" + current_patient_card_no + "' "
            c.execute(query3)
            patient = c.fetchall()
            current_patient_name = str(patient[0][0]) + ' ' +  str(patient[0][1]) + ' ' + str(patient[0][2])
            date_of_birth = patient[0][3]
            dob = datetime.fromisoformat(date_of_birth)
            age = calculate_age(dob)
            gender = patient[0][4]
            status = incoming_patient[3]
            
            update_referral_note_for_referred_patient(current_patient_card_no)
            

            current_patient.append(no_of_waiting_patients)
            current_patient.append(current_patient_queue_no)
            current_patient.append(current_patient_name)
            current_patient.append(age)
            current_patient.append(gender)
            current_patient.append(current_patient_card_no)
            current_patient.append(status)

            return current_patient


        def call_patient():
            try:
                next_patient_details = call_next(staff_id)
                t1.set(next_patient_details[0])
                t2.set(next_patient_details[1])
                t3.set(next_patient_details[2])
                t4.set(next_patient_details[3])
                t5.set(next_patient_details[4])
                t6.set(next_patient_details[5])
                t9.set(next_patient_details[6])

            except TypeError:
                return
            
        

        def get_dpt():
            c.execute("SELECT name FROM department GROUP BY name ORDER BY name desc")
            departments = []
            rows = c.fetchall()
                           
            for row in rows:
                departments.append(row[0])

            return departments

        def get_role():
            c.execute("SELECT name FROM role GROUP BY name ORDER BY name desc")
            roles = []
            rows = c.fetchall()

            for row in rows:
                roles.append(row[0])
            
            return roles

        def update_current_queue_status(status, staff_id, card_no):
            query3 = "UPDATE queue SET status = '{}' WHERE staff_id LIKE '{}' AND patient_card_no LIKE '{}'".format(status, staff_id, card_no)
            c.execute(query3)
            conn.commit()

        def skip_current():
            card_no = t6.get()
            status = 'SKIPPED'
            if messagebox.askyesno('SKIP!','Do you want to skip the current patient for taking too long?'):
                update_current_queue_status(status, staff_id, card_no)
                messagebox.showinfo('SKIPPED!',
                    'The patient has been skipped. \n'
                    'Call the next patient.')
            else:
                return

        def refer():
            pass

        def update_current_patient_visit_record(tests, results, id):
            query1 = "UPDATE visit SET tests = '{}', results = '{}' WHERE id LIKE '{}'".format(tests, results, id)
            c.execute(query1)
            conn.commit()

        def update_current_patient_queue_status_to_closed(department, card_no, staff_id):
            status = 'CLOSED'
            query = "UPDATE queue SET status ='{}' WHERE patient_card_no LIKE '{}' AND staff_id LIKE '{}' AND department LIKE '{}'".format(status, card_no, staff_id, department)
            print(query)
            c.execute(query)
            conn.commit()

        def send_patient_back(card_no):
            staff_id = get_referer_id(card_no)
            query = "UPDATE queue SET status = 'RETURNING' WHERE patient_card_no LIKE '{}' AND staff_id LIKE '{}' AND status LIKE 'REFERRED'".format(card_no, staff_id)
            c.execute(query)
            conn.commit()

        def clear_lab_entries():
            txtreferralnote.delete('1.0', END)
            txttests.delete('1.0', END)
            txtresults.delete('1.0', END)
            t7.set('')
            t8.set('')


        def send_results():
            c = conn.cursor()
            card_no = t6.get()
            referral_note = get_referral_note(card_no)
            tests = txttests.get("1.0", END)
            results = txtresults.get("1.0", END)
            id = get_visit_id(card_no)
            department = get_current_department(card_no, staff_id)

            if len(tests) > 2 and len(results) > 2:
                if referral_note == '':
                    messagebox.showerror('ERROR!','The patient was not referred')
                    return

                else:
                    update_current_patient_visit_record(tests, results, id)
                    update_current_patient_queue_status_to_closed(department, card_no, staff_id)
                    send_patient_back(card_no)
                    clear_lab_entries()
                    messagebox.showinfo('DONE!',
                        'The results have been sent. \n'
                        'Call the next patient')

            else:
                messagebox.showerror('ERROR!','Fill in the Tests and Results')

        def entry_next():
            pass

        def exit_lab():
            frame.destroy()
            import usertype
            usertype.UserType(root)

        def next_patient():
            frame.destroy()
            from lab import Lab
            Lab(root, staff_id)

        frame = Frame(root, )
        frame.pack(fill=BOTH, expand=True, padx=(0, 0))

        Label(frame, text= get_user(staff_id), font=("times new roman", 40, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=500, y=5)

        Label(frame, text="In Queue:", font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=5, y=100)
        Label(frame,  textvariable = t1, font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=110, y=100)

        Label(frame, text = "Patient Queue No:",font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=150, y=100)
        Label(frame, textvariable = t2 ,font=("times new roman", 15, "bold", "italic"),
                        fg="black", relief=GROOVE).place(x=315, y=100)

        Label(frame, text = "Card No:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=370, y=100)
        Label(frame, textvariable = t6, font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=460, y=100)
        
        Label(frame, text = "Patient Name:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=570, y=100)
        Label(frame, textvariable = t3, font=("times new roman", 15, "bold", "italic"), width=30,
                        relief=GROOVE).place(x=700, y=100)

        Label(frame, text = "Patient Age:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=1040, y=100)
        Label(frame, textvariable = t4, font=("times new roman", 15, "bold", "italic"), width=5,
                        relief=GROOVE).place(x=1180, y=100)
        
        Label(frame, text = "Patient Gender:", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=1040, y=140)
        Label(frame, textvariable = t5, font=("times new roman", 15, "bold", "italic"),  width=9,
                        relief=GROOVE).place(x=1180, y=140)

        Label(frame, text = "Status", font=("times new roman", 15, "bold", "italic"),
                        relief=GROOVE).place(x=600, y=140)
        Label(frame, textvariable = t9, font=("times new roman", 15, "bold", "italic"), width=15,
                        relief=GROOVE).place(x=670, y=140)

        Label(frame, text = "Referral Note:", font = 20, relief=GROOVE).place(x=120, y=200)
        txtreferralnote=scrolledtext.ScrolledText(frame, width=35, height=10, font=("Times New Roman", 15))
        txtreferralnote.place(x=10, y=230,)

        Label(frame, text = "Tests:", font = 20, relief=GROOVE).place(x=600, y=200)
        txttests = scrolledtext.ScrolledText(frame, width=35, height=10, font=("Times New Roman", 15))
        txttests.place(x=450, y=230)

        Label(frame, text = "Results:", font = 20, relief=GROOVE).place(x=1040, y=200)
        txtresults = scrolledtext.ScrolledText(frame, width=35, height=10, font=("Times New Roman", 15))
        txtresults.place(x=900, y=230)


        # Label(frame, text="Department:", compound=LEFT, bg="#a9acb6",
        #                 font=("times new roman", 12, "bold",), ).place(x=500, y=500)
        # txtdpt = ttk.Combobox(frame, width=30, textvariable = t7)
        # txtdpt.place(x=625, y=500)
        # txtdpt.bind("<Return>",entry_next)
        # txtdpt['values'] = get_dpt()

        # Label(frame, text="Specialist:", compound=LEFT, bg="#a9acb6",
        #                 font=("times new roman", 12, "bold",), ).place(x=500, y=550)
        # txtspecialist = ttk.Combobox(frame, width=30, textvariable = t8)
        # txtspecialist.place(x=625, y=550)
        # txtspecialist.bind("<Return>",entry_next)
        # txtspecialist['values'] = get_role()


        Button(frame, text="Skip Current Calling", command=skip_current, font=("", 10, "bold",), bg="#8b4c39", fg="#f6c9cc",
                    width=15).place(x=20, y=50)

        # Button(frame, text="Refer", command=refer, font=("", 10, "bold",), bg="#068481", fg="#b0c4de", width=15).place(
        #     x=700, y=600)
        
        Button(frame, text="Send Results", command=send_results, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=1000, y=500)

        Button(frame, text="Next", command=next_patient, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=1150, y=550)

        Button(frame, text="Exit", command=exit_lab, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=20, y=10)

        call_patient()

# root = Tk()
# Lab(root,'L001')
# root.mainloop()
