from tkinter import *
from tkinter import ttk

import mysql.connector
import functools
from tkcalendar import *
import uuid

from tkinter import messagebox
from datetime import datetime
from tkinter.font import families
from common import get_dpt, get_role, queue_emergency, queue, get_patient_name

class Reception:
    def __init__(self, root, staff_id):

        self.root = root
        self.root.title("HOSPITAL QUEUEING SYSTEM")
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        self.root.geometry("{}x{}+0+0".format(screen_width, screen_height))
        self.root.configure(background="grey")

        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="password#123",
            database = "hospital_db"
        )
        c = conn.cursor()

        
    

        t0 = StringVar()
        t1 = StringVar()
        t2 = StringVar()
        t3 = StringVar()
        t4 = StringVar()
        t5 = StringVar()
        t6 = StringVar()
        t7 = StringVar()
        t8 = StringVar()
        t9 = StringVar()
        t10 = StringVar()

        def clear():
            txtcard_no.delete(0, END)
            txtfname.delete(0, END)
            txtlname.delete(0, END)
            txtothername.delete(0, END)
            txtdob.delete(0, END)
            txtphone.delete(0, END)
            txtgender.delete(0, END)
            txtphone.delete(0, END)
            txtdpt.delete(0, END)
            txtspecialist.delete(0, END)
            txtsearch.delete(0, END)

        def clear_queueing():
            t8.set('')
            t9.set('')
            t10.set('')
        
        def clear_search():
            txtsearch.delete(0, END)

        def calltracker(func):
            @functools.wraps(func)
            def wrapper(*args):
                wrapper.has_been_called=True
                return func(*args)
            wrapper.has_been_called=False
            return wrapper

        def entry_next(event):
            event.widget.tk_focusNext().focus()

        def getemployeerow(event):
            clear()
            global selected_record_id
            selected = tv.focus()
            details = tv.item(selected, 'values')
            t1.set(details[1])
            t2.set(details[2])
            t3.set(details[3])
            t4.set(details[4])
            t5.set(details[5])
            t6.set(details[6])
            t7.set(details[7])

            card_no = details[1]

            query = "SELECT id FROM patient_detail WHERE card_no LIKE '%" + card_no +"%' GROUP BY id ORDER BY id"
            c.execute(query)
            results = c.fetchall()
            selected_record_id = results[0][0]
            print(selected_record_id)


        def exit_getrow():
            pass


        def emergency():
            if t1.get() != "" and t8.get() != "" and t9.get() != "":
                card_no = t1.get()
                department = t8.get().upper()
                specialist = t9.get().upper()
                queue_emergency(department, specialist, card_no)
                clear()
            else:
                messagebox.showerror('ERROR!','Fill in a Card No, Department and Specialist')


        def get_specfic_department(department):
            c.execute("SELECT name FROM department WHERE name LIKE '%" + department + "%' GROUP BY name ORDER BY name desc")
            departments = []

            print(c.fetchall())

            for row in c.fetchall():
                departments.append(row[0])

            return departments
        
        def add_new_patient():
            id=  str(uuid.uuid4())
            tdate = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            card_no= t1.get().upper()
            first_name = t2.get().upper() 
            last_name = t3.get().upper()
            other_name = t4.get().upper()
            date_of_birth = t5.get()
            gender = t6.get().upper()
            phone = t7.get().upper()
            query = "INSERT INTO patient_detail(id, date, card_no, first_name, last_name, other_name, date_of_birth, gender, phone) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
            val = (id, tdate, card_no, first_name, last_name, other_name, date_of_birth, gender, phone)
            c.execute(query, val)
            conn.commit()
            read()

        def create():
            if len(t1.get()) == 0 or len(t2.get()) == 0 or len(t3.get()) == 0 or len(t5.get()) == 0 or len(t8.get()) == 0 or len(t9.get()) == 0: 
                messagebox.showerror('ERROR', " Enter the required values")
                return
            
            if t1.get().isspace() or t2.get().isspace() or t3.get().isspace() or t5.get().isspace() or t8.get().isspace() or t9.get().isspace():
                messagebox.showerror('ERROR', "Enter valid values")
                return
            else:
                pass

            card_no= t1.get().upper()
            department = t8.get().upper()
            specialist = t9.get().upper()

            patient_name = get_patient_name(card_no)
            if patient_name == "":
                add_new_patient()
                queue(department, specialist, card_no)

            else:
                if messagebox.askyesno(
                    'EXISTS',"The patient record already exists.\n"
                    "Do you want to procedd and queue patient?"):
                    queue(department, specialist, card_no)
                else:
                    return

            clear()

        def read():
            tv.delete(*tv.get_children())
            query = "SELECT date, card_no, first_name, last_name, other_name, date_of_birth, gender, phone FROM patient_detail ORDER BY date desc"
            c.execute(query)

            users = c.fetchall()
            for user in users:
                tv.insert('', 'end', values=user)


        def update():
            try:
                update_id = selected_record_id
                if update_id == '':
                    messagebox.showerror('Error','Select Record To Be Updated')
                    return
                else:
                    pass
            except NameError:
                messagebox.showerror('Error','Select Record To Be Updated')
                return

            if len(t1.get()) >= 1 and len(t2.get()) >= 1 and len(t3.get()) >= 1 and len(t4.get()) >= 1 and len(t5.get()) >= 1 and len(t6.get()) >= 1 and len(t7.get()) >= 1:
                pass
            else:
                messagebox.showerror('ERROR', "All fields are required")
                return
            
            if t1.get().isspace() or t2.get().isspace() or t3.get().isspace() or t4.get().isspace() or t5.get().isspace() or t6.get().isspace() or t7.get().isspace():
                messagebox.showerror('ERROR', "Select Record to be Updated")
                return
            else:
                pass

            card_no= t1.get()
            first_name = t2.get().upper() 
            last_name = t3.get().upper()
            other_name = t4.get().upper()
            date_of_birth = t5.get()
            gender = t6.get().upper()
            phone = t7.get().upper()
            
            query = "UPDATE patient_detail SET card_no = '" + card_no +"', first_name = '" + first_name +"', last_name = '" + last_name +"', other_name = '" + other_name +"', date_of_birth = '" + date_of_birth +"', gender = '" + gender +"', phone = '" + phone +"' WHERE id LIKE '" + update_id +"'"

            print(query)

            c.execute(query)
            conn.commit()

            messagebox.showinfo('OK','{} Updated'.format(card_no))
            clear()
            read()

        def delete():
            try:
                delete_id = selected_record_id
                if delete_id == '':
                    messagebox.showerror('Error','Select Record To Be Updated')
                    return
                else:
                    pass
            except NameError:
                messagebox.showerror('Error','Select Record To Be Updated')
                return
            
            if len(t1.get()) >= 1 and len(t2.get()) >= 1 and len(t3.get()) >= 1 and len(t4.get()) >= 1 and len(t5.get()) >= 1 and len(t6.get()) >= 1:
                pass
            else:
                messagebox.showerror('ERROR', "The form requires all fields to be deleted,\n"
                "Select Record To Be Updated")
                return
            if t1.get().isspace() or t2.get().isspace() or t3.get().isspace() or t4.get().isspace() or t5.get().isspace() or t6.get().isspace():
                messagebox.showerror('ERROR', "Select Record to be Deleted")
                return
            else:
                pass

            if messagebox.askyesno("DELETE!","Are you sure you want to delete {} from record".format(t2.get())):    
                query = "DELETE FROM patient_detail WHERE id LIKE '" + delete_id +"'"
                c.execute(query)
                conn.commit()
                card_no = t1.get()
                messagebox.showinfo('Ok', "Successfully deleted {}".format(staff_id))
                clear()
                read()
            else:
                return

        def search():
            card_no = t10.get()
            if card_no == '' or card_no.isspace():
                messagebox.showerror('Eror','Enter a valid user card number')
                return

            query1 = "SELECT * FROM patient_detail WHERE card_no LIKE '" + card_no + "'"
            c.execute(query1)

            patient_details = c.fetchall()
            print("PATIENT DETAILS", patient_details)

            if patient_details == []:
                messagebox.showerror('ERROR!','Enter a valid user card number \n'
                'OR \n'
                'Add patient to records')
                return
            
            else:
                first_name = patient_details[0][3]
                last_name =  patient_details[0][4]
                messagebox.showinfo('OK','{} {} found'.format(first_name, last_name))
                if messagebox.askyesno('QUEUE!','Do yo want to proceed and queue {} {}'.format(first_name, last_name)):
                    queue_by_search()
                    clear_queueing()
                
                else:
                    clear_queueing()
                    return
        
        def search_event(event):
            search()

        def queue_by_search():
            card_no = t10.get()
            department = t8.get().upper()
            specialist = t9.get().upper()

            if card_no == '' or card_no.isspace() or department =='' or department.isspace() or specialist == '' or specialist.isspace():
                messagebox.showerror('ERROR!','Enter Patient Card Number, Department and Specialist')
                return

            query1 = "SELECT * FROM patient_detail WHERE card_no LIKE '" + card_no + "'"
            c.execute(query1)

            patient_details = c.fetchall()
            print(patient_details)

            if patient_details == []:
                messagebox.showerror('ERROR!','Enter a valid user card number \n'
                'OR \n'
                'Add patient to records')
                return

            if messagebox.askyesno('QUEUEING!','Do yo want to proceed and queue {} {}'.format(patient_details[0][3],patient_details[0][4])):
                queue(department, specialist, card_no)
                clear_queueing()
            
            else:
                clear_queueing()
                return


        def reset():
            global selected_record_id
            selected_record_id = ''
            clear()
        

        def exit_reception():
            frame.destroy()
            import usertype
            usertype.UserType(root)

        frame = Frame(root, )
        frame.pack(fill=BOTH, expand=True, padx=(0, 0))

        frame2 = Frame(frame, )
        frame2.place(x=1, y=490, relwidth=1, relheight=0.42)

        formlbl = Label(frame, text="Patients Form", font=("times new roman", 30, "bold", "italic"), bg="#a9acb6",
                        fg="black", relief=GROOVE).place(x=500, y=5)
        
        lblcard_no = Label(frame, text="Card No:", compound=LEFT, bg="#a9acb6",
                         font=("times new roman", 12, "bold",), ).place(x=5, y=70)
        txtcard_no = Entry(frame, width=28, font=("", 13), bg="#a9a9a9", textvariable=t1,)
        txtcard_no.place(x=125, y=70)
        txtcard_no.bind("<Return>", entry_next)

        lblname = Label(frame, text="First Name:", compound=LEFT, bg="#a9acb6",
                         font=("times new roman", 12, "bold",), ).place(x=5, y=110)
        txtfname = Entry(frame, width=28, font=("", 13), bg="#a9a9a9", textvariable=t2,)
        txtfname.place(x=125, y=110)
        txtfname.bind("<Return>", entry_next)

        lblname = Label(frame, text="Last Name:", compound=LEFT, bg="#a9acb6",
                         font=("times new roman", 12, "bold",), ).place(x=5, y=150)
        txtlname = Entry(frame, width=28, font=("", 13), bg="#a9a9a9", textvariable=t3,)
        txtlname.place(x=125, y=150)
        txtlname.bind("<Return>", entry_next)

        lblname = Label(frame, text="Other Name:", compound=LEFT, bg="#a9acb6",
                         font=("times new roman", 12, "bold",), ).place(x=5, y=190)
        txtothername = Entry(frame, width=28, font=("", 13), bg="#a9a9a9", textvariable=t4,)
        txtothername.place(x=125, y=190)
        txtothername.bind("<Return>", entry_next)

        lbldob = Label(frame, text="Date of Birth:", compound=LEFT, bg="#a9acb6",
                         font=("times new roman", 12, "bold",), ).place(x=5, y=230)
        txtdob = DateEntry(frame, width=27, font=("", 13), bg="#a9a9a9", date_pattern='yyyy-MM-dd', textvariable=t5,)
        txtdob.place(x=125, y=230)
        txtdob.bind("<Return>", entry_next)

        lblgender = Label(frame, text="Gender:", compound=LEFT, bg="#a9acb6",
                         font=("times new roman", 12, "bold",), ).place(x=5, y=280)
        txtgender = ttk.Combobox(frame, width=28, font=("", 13), textvariable=t6)
        txtgender.place(x=125, y=280)
        txtgender['values'] = ['MALE', 'FEMALE', 'OTHER']

        lblphone = Label(frame, text="Phone:", compound=LEFT, bg="#a9acb6",
                         font=("times new roman", 12, "bold",), ).place(x=5, y=320)
        txtphone = Entry(frame, width=28, font=("", 13), bg="#a9a9a9", textvariable=t7)
        txtphone.place(x=125, y=320)
        txtphone.bind("<Return>", entry_next)

        Label(frame, text="Department:", compound=LEFT, bg="#a9acb6",
                        font=("times new roman", 12, "bold",), ).place(x=5, y=360)
        txtdpt = ttk.Combobox(frame, width=30, textvariable=t8)
        txtdpt.place(x=125, y=360)
        txtdpt.bind("<Return>",entry_next)
        txtdpt['values'] = get_dpt()

        Label(frame, text="Specialist:", compound=LEFT, bg="#a9acb6",
                        font=("times new roman", 12, "bold",), ).place(x=5, y=400)
        txtspecialist = ttk.Combobox(frame, width=30, textvariable=t9,)
        txtspecialist.place(x=125, y=400)
        txtspecialist.bind("<Return>",entry_next)
        txtspecialist['values'] = get_role()

        txtsearch = Entry(frame, width=18, font=("", 13), bg="#a9a9a9", textvariable=t10)
        txtsearch.place(x=800, y=80)
        txtsearch.bind("<Return>", search_event)

        # Button(frame, text="EMERGENCY", command=emergency, font=("", 10, "bold",), bg="#FF0000", fg="White",
        #             width=15).place(x=1180, y=40)

        Button(frame, text="Search", command=search, font=("", 10, "bold",), bg="#068481", fg="#b0c4de",
                    width=11).place(x=1030, y=80)
        
        Button(frame, text="Queue", command=queue_by_search, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=11).place(x=1030, y=120)

        Button(frame, text="Add & Queue", command=create, font=("", 10, "bold",), bg="#068481", fg="#b0c4de",
                    width=15).place(x=480, y=440)
        Button(frame, text="Display", command=read, font=("", 10, "bold",), bg="#506987", fg="#c1cdc1",
                    width=15).place(x=650, y=440)
        Button(frame, text="Update", command=update, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=830, y=440)
        Button(frame, text="Delete", command=delete, font=("", 10, "bold",), bg="#8b4c39", fg="#f6c9cc",
                    width=15).place(x=1000, y=440)
        Button(frame, text="Reset", command=reset, font=("", 10, "bold",), bg="#003f87", fg="White",
                    width=15).place(x=1180, y=440)

        Button(frame, text="Exit", command=exit_reception, font=("", 10, "bold",), bg="#1b6453", fg="#eab5c5",
                    width=15).place(x=20, y=10)

# ===============================================Create table==================================================
        tv = ttk.Treeview(frame2, columns=(1, 2, 3, 4, 5, 6, 7, 8), show="headings", height="5")
        xscrollbar = ttk.Scrollbar(frame2, orient="horizontal", command=tv.xview)
        xscrollbar.pack(side=BOTTOM, fill="x")
        yscrollbar = ttk.Scrollbar(frame2, orient=VERTICAL, command=tv.yview)
        yscrollbar.pack(side=RIGHT, fill=Y)

        tv.configure(xscrollcommand=xscrollbar.set)
        tv.configure(yscrollcommand=yscrollbar.set)

        tv.column(1, width=100)
        tv.column(2, width=100)
        tv.column(3, width=200)
        tv.column(4, width=200)
        tv.column(5, width=200)
        tv.column(6, width=100)
        tv.column(7, width=50)
        tv.column(8, width=100)
        
        tv.heading(1, text="Date")
        tv.heading(2, text="Card No")
        tv.heading(3, text="First Name")
        tv.heading(4, text="Last Name")
        tv.heading(5, text="Other Name")
        tv.heading(6, text="Date of Birth")
        tv.heading(7, text="Gender")
        tv.heading(8, text="Phone")
        

        tv.bind('<Double-1>', getemployeerow)
        tv.pack(fill=BOTH, expand=1)


# root = Tk()
# Reception(root, "staff_id")
# root.mainloop()