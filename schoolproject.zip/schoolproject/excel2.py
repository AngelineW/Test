import random

value = random.randint(1,100000)
print(value)